#!/bin/bash
# 🐾 小司 - 一键启动脚本
# 双击即可运行，自动查找项目文件夹

echo "🐾 正在查找小司的项目文件夹..."

# 在常见位置搜索
SEARCH_DIRS=(
  "$HOME/Desktop"
  "$HOME/Documents"
  "$HOME/Downloads"
  "$HOME"
)

FOUND=""

for dir in "${SEARCH_DIRS[@]}"; do
  if [ -d "$dir/xiaosi-app" ]; then
    FOUND="$dir/xiaosi-app"
    break
  fi
done

# 如果常见位置没找到，全局搜索
if [ -z "$FOUND" ]; then
  echo "🔍 常见位置没找到，正在全盘搜索..."
  FOUND=$(find "$HOME" -name "xiaosi-app" -type d -maxdepth 5 2>/dev/null | head -1)
fi

if [ -z "$FOUND" ]; then
  echo "❌ 找不到 xiaosi-app 文件夹！"
  echo ""
  echo "请确认："
  echo "  1. 已经下载了 xiaosi-desktop-pet.zip"
  echo "  2. 已经解压了 zip 文件"
  echo ""
  echo "解压后重新双击本脚本即可。"
  echo ""
  read -p "按回车键退出..."
  exit 1
fi

echo "✅ 找到了：$FOUND"
cd "$FOUND"

# 检查 Node.js
if ! command -v node &> /dev/null; then
  echo "❌ 没有安装 Node.js！"
  echo ""
  echo "请先安装 Node.js："
  echo "  👉 打开 https://nodejs.org"
  echo "  👉 下载 LTS 版本并安装"
  echo ""
  read -p "按回车键退出..."
  exit 1
fi

echo "✅ Node.js 版本：$(node -v)"
echo ""

# 设置国内镜像（必须在 npm install 之前）
export ELECTRON_MIRROR="https://npmmirror.com/mirrors/electron/"
export npm_config_registry="https://registry.npmmirror.com"

# 检查是否需要安装依赖
if [ ! -d "node_modules/electron" ]; then
  echo "📦 首次运行，正在安装依赖（使用国内镜像，可能需要2-3分钟）..."
  echo "   ⏳ Electron 比较大，请耐心等待..."
  npm install 2>&1 | cat
  if [ $? -ne 0 ]; then
    echo ""
    echo "❌ 安装失败！请检查网络连接后重试。"
    read -p "按回车键退出..."
    exit 1
  fi
  echo ""
  echo "✅ 安装完成！"
fi

echo "🚀 启动小司！"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
./node_modules/.bin/electron .
