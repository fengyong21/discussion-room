---
name: governance-compliance
description: |
  治理合规技能——制定和执行组织政策。
  触发词：治理、制度、政策、标准、最佳实践
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "AI治理 趋势 2026"
  - type: best_practice
    query: "AI合规 最佳实践"
  - type: competitor
    query: "治理工具"
  - type: tech_update
    query: "AI监管 政策"
  - type: beginner_insight
    query: "AI治理 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增全球多法域治理合规知识图谱、数字资产与数据跨境流动专项治理
  ]
---

# 治理合规

## 调用时机
- 需要制定组织政策
- 需要执行制度监督
- 需要处理违规行为

## 工作流

### Phase 1: 制度制定
- 组织级AI使用政策和标准
- 输出：制度文档

### Phase 2: 执行监督
- 自动检查Skill输出是否符合制度
- 输出：监督报告

### Phase 3: 违规处理
- 违规行为识别 + 自动纠正
- 输出：处理记录

### Phase 4: 制度进化
- 基于执行反馈持续优化制度
- 输出：制度更新
