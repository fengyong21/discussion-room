---
name: data-modeling
description: |
  数据建模技能——构建预测模型和推荐系统。
  触发词：机器学习、预测模型、推荐系统、NLP、AI模型
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 69/100
learning_sources:
  - type: industry_trend
    query: "机器学习 趋势 2026"
  - type: best_practice
    query: "数据建模 最佳实践"
  - type: competitor
    query: "ML平台 竞品"
  - type: tech_update
    query: "ML框架 更新"
  - type: beginner_insight
    query: "机器学习 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增数字孪生/多模态数据建模、业务需求到模型设计自动化映射、模型质量评估机制
  ]
---

# 数据建模

## 调用时机
- 需要构建预测模型
- 需要做推荐系统
- 需要做NLP处理

## 工作流

### Phase 1: 问题定义
- 将业务问题转化为建模任务
- 输出：建模任务定义

### Phase 2: 特征工程
- 特征提取、选择、构造
- 输出：特征集

### Phase 3: 模型训练
- 算法选择、超参调优、交叉验证
- 输出：训练好的模型

### Phase 4: 模型评估
- 离线评估 + A/B测试
- 输出：评估报告
