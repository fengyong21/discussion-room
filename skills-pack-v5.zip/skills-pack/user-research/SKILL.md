---
name: user-research
description: |
  用户研究技能——进行用户访谈和行为分析。
  触发词：用户访谈、问卷调查、可用性测试、用户行为
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 67/100
learning_sources:
  - type: industry_trend
    query: "用户研究 方法 2026"
  - type: best_practice
    query: "用户访谈 技巧"
  - type: competitor
    query: "用户研究工具"
  - type: tech_update
    query: "用户行为分析 技术"
  - type: beginner_insight
    query: "用户研究 新手怎么做"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI驱动的用户行为分析、多模态用户反馈采集、实时情感分析研究方法
  ]
---

# 用户研究

## 调用时机
- 需要了解用户需求
- 需要进行用户访谈或问卷
- 需要做可用性测试

## 工作流

### Phase 1: 研究设计
- 确定研究方法和样本
- 输出：研究计划

### Phase 2: 数据收集
- 执行访谈/问卷/行为分析
- 输出：原始数据

### Phase 3: 洞察提炼
- 从原始数据中提取用户洞察
- 输出：洞察清单

### Phase 4: 报告输出
- 结构化用户研究报告
- 输出：研究报告
