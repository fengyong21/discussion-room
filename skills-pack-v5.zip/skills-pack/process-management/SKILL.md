---
name: process-management
description: |
  流程管理技能——优化业务流程和SOP。
  触发词：流程优化、SOP、自动化、效率提升
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 68/100
learning_sources:
  - type: industry_trend
    query: "流程优化 趋势 2026"
  - type: best_practice
    query: "流程管理 最佳实践"
  - type: competitor
    query: "流程自动化工具"
  - type: tech_update
    query: "RPA 低代码"
  - type: beginner_insight
    query: "流程优化 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI原生流程设计能力、价值驱动的流程重构方法论、全域协同视角
  ]
---

# 流程管理

## 调用时机
- 需要优化业务流程
- 需要制定SOP
- 需要提升效率

## 工作流

### Phase 1: 流程映射
- 现有流程可视化（流程图）
- 输出：流程图

### Phase 2: 瓶颈识别
- 基于数据的流程瓶颈分析
- 输出：瓶颈清单

### Phase 3: 优化方案
- 自动化机会识别 + 改进建议
- 输出：优化方案

### Phase 4: SOP生成
- 标准操作流程文档
- 输出：SOP文档
