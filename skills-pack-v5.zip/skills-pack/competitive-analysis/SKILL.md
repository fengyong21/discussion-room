---
name: competitive-analysis
description: |
  竞品分析技能——系统分析竞争对手的策略和能力。
  触发词：竞品、竞争对手、对标分析、差异化
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 71/100
learning_sources:
  - type: industry_trend
    query: "竞品分析 行业格局 2026"
  - type: best_practice
    query: "竞品分析 方法论 框架"
  - type: competitor
    query: "竞品监控工具"
  - type: tech_update
    query: "竞品分析 AI工具"
  - type: beginner_insight
    query: "竞品分析 入门教程"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助竞品情报搜集工作流、认知维度竞品分析（战略意图/组织能力/生态布局）、社媒矩阵竞品监测模块
  ]
---

# 竞品分析

## 调用时机
- 需要分析竞争对手
- 需要做竞品对标
- 需要制定差异化策略

## 工作流

### Phase 1: 竞品识别
- 自动发现和分类竞争对手
- 输出：竞品清单

### Phase 2: 特征对标
- 功能/价格/体验/技术栈对比矩阵
- 输出：对比矩阵

### Phase 3: 差异化识别
- 发现竞品的优势和盲区
- 输出：差异化分析

### Phase 4: 策略建议
- 基于分析的差异化策略建议
- 输出：策略建议文档
