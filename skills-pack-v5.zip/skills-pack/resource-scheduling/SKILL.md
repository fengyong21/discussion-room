---
name: resource-scheduling
description: |
  资源调度技能——优化资源分配和容量规划。
  触发词：排班、容量规划、负载均衡、资源分配
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 68/100
learning_sources:
  - type: industry_trend
    query: "资源管理 趋势 2026"
  - type: best_practice
    query: "资源调度 最佳实践"
  - type: competitor
    query: "排班工具"
  - type: tech_update
    query: "项目管理 资源"
  - type: beginner_insight
    query: "资源管理 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI驱动动态资源调度模型、多场景智能分配与风险预判
  ]
---

# 资源调度

## 调用时机
- 需要规划资源容量
- 需要做排班调度
- 需要优化负载均衡

## 工作流

### Phase 1: 需求预测
- 基于项目计划的资源需求预测
- 输出：需求预测

### Phase 2: 容量评估
- 当前资源利用率分析
- 输出：容量报告

### Phase 3: 调度优化
- 负载均衡、优先级调度
- 输出：调度计划

### Phase 4: 预警机制
- 资源不足/过剩预警
- 输出：预警信息
