---
name: strategic-analysis
description: |
  战略分析技能——进行市场环境分析和战略方向判断。
  触发词：战略规划、SWOT、商业模式、行业趋势、竞争态势
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 72/100
learning_sources:
  - type: industry_trend
    query: "战略规划 行业趋势 2026"
  - type: best_practice
    query: "战略分析 最佳实践"
  - type: competitor
    query: "竞争对手 战略调整"
  - type: tech_update
    query: "战略分析工具 AI"
  - type: beginner_insight
    query: "战略规划 新手入门 常见问题"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI战略成熟度评估模块、3x3战略矩阵方法论、GEO战略布局分析维度、智效跃迁评估指标
  ]
---

# 战略分析

## 调用时机
- 需要制定战略方向
- 需要进行SWOT分析或商业模式分析
- 需要判断行业趋势

## 工作流

### Phase 1: 信息汇聚
- 收集市场数据、行业报告、内部运营数据
- 输出：信息汇总清单

### Phase 2: 环境分析
- PESTEL分析 + 波特五力 + SWOT
- 输出：结构化分析框架

### Phase 3: 趋势预判
- 基于数据的市场趋势预测（3/6/12个月）
- 输出：趋势预测报告

### Phase 4: 战略选项生成
- 产出3-5个战略方向，附带可行性评分
- 输出：战略选项矩阵

## 检查点
- Phase 4 完成后需人类确认战略方向
