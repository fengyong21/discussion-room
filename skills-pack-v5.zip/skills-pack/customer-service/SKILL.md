---
name: customer-service
description: |
  客户服务技能——处理客户问题和投诉。
  触发词：客服、工单、投诉、售后、客户支持
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 69/100
learning_sources:
  - type: industry_trend
    query: "客服 趋势 2026"
  - type: best_practice
    query: "客户服务 最佳实践"
  - type: competitor
    query: "客服工具 竞品"
  - type: tech_update
    query: "AI客服 技术"
  - type: beginner_insight
    query: "客服 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI智能客服多轮对话管理、情感分析与智能升级、全渠道统一客服视图
  ]
---

# 客户服务

## 调用时机
- 需要处理客户投诉
- 需要回复客户问题
- 需要做客户满意度管理

## 工作流

### Phase 1: 工单接收
- 多渠道接入（邮件/聊天/电话）
- 输出：工单记录

### Phase 2: 智能分类
- 问题分类 + 优先级 + 情感分析
- 输出：分类结果

### Phase 3: 自动响应
- 常见问题自动解答，复杂问题升级
- 输出：响应内容

### Phase 4: 满意度跟踪
- 自动回访 + 满意度评分
- 输出：满意度报告
