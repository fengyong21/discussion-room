---
name: code-review
description: |
  代码审查技能——审查代码质量和安全性。
  触发词：Code Review、PR审查、代码质量
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 71/100
learning_sources:
  - type: industry_trend
    query: "代码审查 标准 2026"
  - type: best_practice
    query: "Code Review 最佳实践"
  - type: competitor
    query: "代码审查工具"
  - type: tech_update
    query: "静态分析 技术"
  - type: beginner_insight
    query: "代码审查 新手"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI生成代码专项审查、AI代码幻觉检测、安全漏洞模式识别、人机协作审查流程
  ]
---

# 代码审查

## 调用时机
- 需要审查代码质量
- 需要做PR Review
- 需要检查代码安全性

## 工作流

### Phase 1: 自动扫描
- 静态分析、依赖检查、安全漏洞扫描
- 输出：扫描报告

### Phase 2: 逻辑审查
- 业务逻辑正确性、边界条件
- 输出：逻辑问题清单

### Phase 3: 最佳实践
- 设计模式、性能优化建议
- 输出：改进建议

### Phase 4: 审查报告
- 结构化审查意见（通过/修改/拒绝）
- 输出：审查报告
