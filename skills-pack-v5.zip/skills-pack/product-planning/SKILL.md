---
name: product-planning
description: |
  产品规划技能——将业务需求转化为结构化的产品方案。
  触发词：产品规划、需求分析、PRD、功能设计、路线图、产品方案
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 68/100
learning_sources:
  - type: industry_trend
    query: "产品管理 趋势 2026"
  - type: best_practice
    query: "PRD撰写 最佳实践"
  - type: competitor
    query: "产品管理工具 竞品"
  - type: tech_update
    query: "产品规划 AI工具"
  - type: beginner_insight
    query: "产品规划 新手入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI原生产品规划方法论、多模态产品体验设计、AI Agent产品化路径
  ]
---

# 产品规划

## 调用时机
- 需要规划产品功能或版本迭代
- 需要撰写PRD或产品需求文档
- 需要制定产品路线图

## 工作流

### Phase 1: 需求汇聚
- 收集并整理业务需求
- 识别核心用户痛点和业务目标
- 输出：需求清单（含优先级标记）

### Phase 2: 方案设计
- 设计2-3个候选方案
- 每个方案包含：核心功能、技术可行性、预估成本、风险评估
- 输出：方案对比矩阵

### Phase 3: PRD 输出
- 生成结构化产品需求文档
- 包含：背景、目标用户、功能列表、非功能需求、验收标准
- 输出：PRD 文档

### Phase 4: 路线图
- 制定短期（1-2周）、中期（1-3月）、长期（3-6月）路线图
- 标注里程碑和依赖关系

## 检查点
- Phase 2 完成后需人类确认方案方向
- Phase 3 完成后需人类确认需求细节
