---
name: code-development
description: |
  代码开发技能——根据需求和架构设计编写高质量代码。
  触发词：编码、开发、实现、功能开发、Bug修复、写代码
version: 1.1.0
evolution_cycle: 7d
last_evolved: 2026-04-18
evolution_count: 1
score: 72/100
learning_sources:
  - type: industry_trend
    query: "编程语言 更新 2026"
  - type: best_practice
    query: "代码质量 最佳实践"
  - type: competitor
    query: "开发工具 IDE"
  - type: tech_update
    query: "编程框架 新功能"
  - type: beginner_insight
    query: "编程入门 新手常见问题"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI智能体协作开发模式、Agentic AI工作流编排、AI生成代码质量把关机制、低代码+AI融合开发
  ]
---

# 代码开发

## 调用时机
- 需要编写代码或开发功能
- 需要修复Bug
- 需要实现具体的技术方案

## 工作流

### Phase 1: 任务分析
- 理解需求和验收标准
- 确认技术栈和编码规范
- 识别需要修改/新建的文件

### Phase 2: 编码实现
- 按模块逐步实现功能
- 遵循最佳实践和设计模式
- 编写必要的注释

### Phase 3: 自检
- 代码风格检查
- 边界条件检查
- 安全隐患检查

### Phase 4: 提交
- 生成 commit message
- 生成 PR 描述（含改动摘要和测试说明）

## 约束
- 不引入未经确认的新依赖
- 不修改与当前任务无关的代码
- 每次只完成一个明确的编码任务
