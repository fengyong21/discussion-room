---
name: project-coordination
description: |
  项目协调技能——管理和跟踪项目进度。
  触发词：项目管理、进度跟踪、任务分配、里程碑、Scrum
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 68/100
learning_sources:
  - type: industry_trend
    query: "项目管理 趋势 2026"
  - type: best_practice
    query: "敏捷开发 最佳实践"
  - type: competitor
    query: "项目管理工具"
  - type: tech_update
    query: "协作平台 更新"
  - type: beginner_insight
    query: "项目管理 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助项目风险预判、多智能体任务分配、实时项目健康度仪表盘
  ]
---

# 项目协调

## 调用时机
- 需要管理项目进度
- 需要分配任务
- 需要跟踪里程碑

## 工作流

### Phase 1: 任务拆解
- WBS工作分解结构
- 输出：任务清单

### Phase 2: 资源匹配
- 根据任务需求匹配Skill
- 输出：资源分配计划

### Phase 3: 进度跟踪
- 里程碑监控、阻塞识别
- 输出：进度报告

### Phase 4: 风险预警
- 延期风险、资源冲突预警
- 输出：风险预警
