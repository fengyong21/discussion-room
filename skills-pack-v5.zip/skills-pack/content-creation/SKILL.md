---
name: content-creation
description: |
  内容创作技能——创作高质量的商业内容。
  触发词：文案、博客、视频脚本、白皮书、文章、内容创作
version: 1.1.0
evolution_cycle: 7d
last_evolved: 2026-04-18
evolution_count: 1
score: 72/100
learning_sources:
  - type: industry_trend
    query: "内容营销 趋势 2026"
  - type: best_practice
    query: "内容创作 最佳实践"
  - type: competitor
    query: "内容平台 规则变化"
  - type: tech_update
    query: "AI写作工具"
  - type: beginner_insight
    query: "内容创作 入门 新手"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助内容生产工作流、多平台内容适配自动化、爆款内容AI分析框架
  ]
---

# 内容创作

## 调用时机
- 需要创作文案或内容
- 需要写博客、文章、视频脚本
- 需要生成营销内容

## 工作流

### Phase 1: 创意策划
- 明确目标受众和传播目标
- 确定内容类型和风格调性
- 输出：内容大纲

### Phase 2: 内容生产
- 按大纲撰写完整内容
- 确保逻辑清晰、语言流畅
- 适当使用数据和案例支撑

### Phase 3: SEO 优化
- 关键词布局优化
- 标题和摘要优化

### Phase 4: 质量审核
- 事实核查
- 品牌调性一致性检查
