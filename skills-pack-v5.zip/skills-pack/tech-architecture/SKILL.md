---
name: tech-architecture
description: |
  技术架构技能——设计系统架构和技术方案。
  触发词：架构设计、系统设计、技术选型、API设计、微服务
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "系统架构 趋势 2026"
  - type: best_practice
    query: "架构设计 最佳实践"
  - type: competitor
    query: "架构工具 竞品"
  - type: tech_update
    query: "云架构 技术"
  - type: beginner_insight
    query: "系统架构 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI原生架构设计模式、多智能体协同架构、边缘计算+云原生混合架构
  ]
---

# 技术架构

## 调用时机
- 需要设计系统架构
- 需要做技术选型
- 需要定义API接口

## 工作流

### Phase 1: 需求分析
- 技术需求提取（性能、安全、可扩展性）
- 输出：技术需求文档

### Phase 2: 架构设计
- 系统架构图、数据流、接口定义
- 输出：架构设计文档

### Phase 3: 技术选型
- 基于场景的技术栈推荐（附对比分析）
- 输出：技术选型报告

## 检查点
- 关键技术决策需人类审批
