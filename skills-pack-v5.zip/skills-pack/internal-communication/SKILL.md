---
name: internal-communication
description: |
  内部沟通技能——自动生成和分发内部信息。
  触发词：周报、会议纪要、公告、全员通知、跨部门
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 67/100
learning_sources:
  - type: industry_trend
    query: "企业沟通 趋势 2026"
  - type: best_practice
    query: "内部沟通 最佳实践"
  - type: competitor
    query: "协作工具"
  - type: tech_update
    query: "AI写作 助手"
  - type: beginner_insight
    query: "周报 会议纪要 模板"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助内部信息摘要与分发、跨团队知识同步自动化、智能会议纪要生成
  ]
---

# 内部沟通

## 调用时机
- 需要写周报/月报
- 需要整理会议纪要
- 需要发全员公告

## 工作流

### Phase 1: 信息收集
- 自动汇总各Skill的关键产出
- 输出：信息汇总

### Phase 2: 内容生成
- 周报/月报/会议纪要自动生成
- 输出：内容草稿

### Phase 3: 智能分发
- 根据角色和关注点定向推送
- 输出：分发确认

### Phase 4: 反馈收集
- 信息触达率和理解度追踪
- 输出：反馈报告
