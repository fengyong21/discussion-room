---
name: conflict-resolution
description: |
  冲突解决技能——调解Skill之间的目标冲突。
  触发词：冲突、分歧、优先级争议、资源争抢
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 67/100
learning_sources:
  - type: industry_trend
    query: "冲突管理 方法 2026"
  - type: best_practice
    query: "冲突调解 技巧"
  - type: competitor
    query: "冲突管理工具"
  - type: tech_update
    query: "沟通技巧 AI"
  - type: beginner_insight
    query: "冲突解决 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助冲突预警机制、远程团队冲突调解方法、数据驱动的冲突根因分析
  ]
---

# 冲突解决

## 调用时机
- Skill之间出现目标冲突
- 资源分配有争议
- 优先级需要仲裁

## 工作流

### Phase 1: 冲突识别
- 自动检测Skill之间的目标冲突
- 输出：冲突清单

### Phase 2: 影响分析
- 评估冲突对项目的影响
- 输出：影响评估

### Phase 3: 方案生成
- 提出多个妥协方案
- 输出：解决方案

## 检查点
- 无法自动解决的冲突升级至人类
