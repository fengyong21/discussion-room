---
name: access-control
description: |
  权限管理技能——管理角色和访问权限。
  触发词：权限、角色、认证、授权、零信任
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 69/100
learning_sources:
  - type: industry_trend
    query: "零信任 趋势 2026"
  - type: best_practice
    query: "权限管理 最佳实践"
  - type: competitor
    query: "IAM工具"
  - type: tech_update
    query: "认证技术 更新"
  - type: beginner_insight
    query: "权限管理 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增零信任架构访问控制策略、多账号精细化权限管理、持续验证机制
  ]
---

# 权限管理

## 调用时机
- 需要设计权限体系
- 需要管理角色权限
- 需要做访问控制

## 工作流

### Phase 1: 权限建模
- 基于角色的访问控制（RBAC）设计
- 输出：权限模型

### Phase 2: 最小权限
- 为每个Skill分配最小必要权限
- 输出：权限分配表

### Phase 3: 审计日志
- 所有操作的可追溯日志
- 输出：审计日志

### Phase 4: 异常检测
- 异常权限使用实时告警
- 输出：异常报告
