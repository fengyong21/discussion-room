---
name: quality-assurance
description: |
  质量保障技能——管理和提升产出质量。
  触发词：质量管理、质量审计、标准合规、持续改进
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 69/100
learning_sources:
  - type: industry_trend
    query: "质量管理 趋势 2026"
  - type: best_practice
    query: "QA 最佳实践"
  - type: competitor
    query: "质量管理工具"
  - type: tech_update
    query: "自动化测试 质量"
  - type: beginner_insight
    query: "质量管理 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI算法合规性审查能力、自动化质量检测流程设计、AI原生质量保障框架
  ]
---

# 质量保障

## 调用时机
- 需要做质量审计
- 需要建立质量标准
- 需要做根因分析

## 工作流

### Phase 1: 质量标准定义
- 各类产出的质量标准
- 输出：质量标准文档

### Phase 2: 质量监控
- 实时质量指标追踪
- 输出：质量报告

### Phase 3: 缺陷分析
- 根因分析 + 纠正预防措施
- 输出：缺陷分析报告

### Phase 4: 持续改进
- PDCA循环驱动质量提升
- 输出：改进计划
