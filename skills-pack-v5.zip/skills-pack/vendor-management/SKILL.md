---
name: vendor-management
description: |
  供应商管理技能——评估和管理供应商。
  触发词：供应商、采购、合同、SLA、外包
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 68/100
learning_sources:
  - type: industry_trend
    query: "供应链 趋势 2026"
  - type: best_practice
    query: "供应商管理 最佳实践"
  - type: competitor
    query: "采购平台"
  - type: tech_update
    query: "合同管理 工具"
  - type: beginner_insight
    query: "供应商管理 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI驱动供应商风险评估与智能选型、供应商全生命周期动态评分模型
  ]
---

# 供应商管理

## 调用时机
- 需要评估供应商
- 需要管理采购合同
- 需要监控供应商绩效

## 工作流

### Phase 1: 供应商评估
- 能力评估 + 风险评估
- 输出：评估报告

### Phase 2: 合同管理
- SLA定义 + 条款审核
- 输出：合同文档

### Phase 3: 绩效监控
- 交付质量、时效、成本追踪
- 输出：绩效报告

### Phase 4: 关系维护
- 定期评审 + 关系优化
- 输出：评审记录
