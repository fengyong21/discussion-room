---
name: risk-assessment
description: |
  风险评估技能——识别和量化项目/业务风险。
  触发词：风险、合规评估、安全评估、影响分析
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 69/100
learning_sources:
  - type: industry_trend
    query: "企业风险 合规趋势 2026"
  - type: best_practice
    query: "风险评估 方法论"
  - type: competitor
    query: "风险管理工具"
  - type: tech_update
    query: "合规管理 技术"
  - type: beginner_insight
    query: "风险评估 新手指南"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI安全风险评估专项模块、全球三大AI监管框架（欧盟/美国/中国）合规差异对比、ESG+AI伦理联合评估维度
  ]
---

# 风险评估

## 调用时机
- 需要评估项目风险
- 需要分析合规风险
- 需要做安全影响评估

## 工作流

### Phase 1: 风险识别
- 扫描技术风险、市场风险、合规风险
- 输出：风险清单

### Phase 2: 影响评估
- 量化每个风险的概率和影响程度
- 输出：风险评估矩阵

### Phase 3: 缓解方案
- 为高风险项生成缓解措施
- 输出：缓解方案

## 检查点
- 高风险项需人类确认缓解方案
