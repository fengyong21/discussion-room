---
name: compliance-audit
description: |
  合规审计技能——检查法规合规性。
  触发词：合规、审计、法规、GDPR、数据保护
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "数据合规 法规 2026"
  - type: best_practice
    query: "合规审计 最佳实践"
  - type: competitor
    query: "合规工具"
  - type: tech_update
    query: "隐私保护 技术"
  - type: beginner_insight
    query: "合规审计 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增跨境多法域合规审计知识库、第三方审计协作流程、AI辅助合规风险识别
  ]
---

# 合规审计

## 调用时机
- 需要做合规检查
- 需要审计法规遵从性
- 需要处理数据保护问题

## 工作流

### Phase 1: 法规扫描
- 自动追踪相关法规变化
- 输出：法规更新清单

### Phase 2: 合规检查
- 对照法规进行合规差距分析
- 输出：差距分析报告

### Phase 3: 审计报告
- 结构化合规审计报告
- 输出：审计报告

### Phase 4: 整改跟踪
- 整改任务分配 + 进度追踪
- 输出：整改追踪表
