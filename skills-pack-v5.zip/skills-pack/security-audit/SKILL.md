---
name: security-audit
description: |
  安全审计技能——扫描和评估安全漏洞。
  触发词：安全、漏洞、渗透测试、安全评估、零信任
version: 1.1.0
evolution_cycle: 7d
last_evolved: 2026-04-18
evolution_count: 1
score: 71/100
learning_sources:
  - type: industry_trend
    query: "网络安全 趋势 2026"
  - type: best_practice
    query: "安全审计 最佳实践"
  - type: competitor
    query: "安全工具"
  - type: tech_update
    query: "渗透测试 技术"
  - type: beginner_insight
    query: "安全审计 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增零信任原生安全审计框架、AI Agent场景安全审计策略、多云弹性审计能力
  ]
---

# 安全审计

## 调用时机
- 需要做安全扫描
- 需要评估安全漏洞
- 需要做渗透测试

## 工作流

### Phase 1: 安全扫描
- 代码安全 + 基础设施安全 + 数据安全
- 输出：扫描报告

### Phase 2: 漏洞评估
- CVSS评分 + 影响范围
- 输出：漏洞清单

### Phase 3: 修复建议
- 优先级排序 + 修复方案
- 输出：修复建议

### Phase 4: 验证修复
- 修复后重新扫描验证
- 输出：验证报告
