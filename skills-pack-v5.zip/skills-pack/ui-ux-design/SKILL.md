---
name: ui-ux-design
description: |
  UI/UX设计技能——设计用户界面和交互体验。
  触发词：设计、界面、交互、原型、Figma、用户体验
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 69/100
learning_sources:
  - type: industry_trend
    query: "UI设计趋势 2026"
  - type: best_practice
    query: "UX设计 最佳实践"
  - type: competitor
    query: "设计工具 Figma更新"
  - type: tech_update
    query: "设计系统 组件库"
  - type: beginner_insight
    query: "UI设计 新手入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助设计工具链、空间计算UI设计规范、情感化设计评估指标
  ]
---

# UI/UX设计

## 调用时机
- 需要设计界面原型
- 需要定义交互流程
- 需要制定设计规范

## 工作流

### Phase 1: 设计研究
- 用户旅程图、信息架构
- 输出：设计研究文档

### Phase 2: 原型设计
- 低/高保真原型生成
- 输出：原型文件

### Phase 3: 设计规范
- 组件库、设计令牌、交互规范
- 输出：设计规范文档

### Phase 4: 可用性验证
- 基于设计原则的自动审查
- 输出：可用性检查报告
