---
name: user-growth
description: |
  用户增长技能——设计和执行增长实验。
  触发词：增长黑客、A/B测试、转化率、留存、裂变
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "用户增长 趋势 2026"
  - type: best_practice
    query: "增长黑客 方法论"
  - type: competitor
    query: "A/B测试 工具"
  - type: tech_update
    query: "转化优化 技术"
  - type: beginner_insight
    query: "用户增长 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助内容生产与智能分发策略、用户生命周期全链路增长模型
  ]
---

# 用户增长

## 调用时机
- 需要提升转化率
- 需要做A/B测试
- 需要设计增长策略

## 工作流

### Phase 1: 增长实验设计
- 假设→变量→指标→样本量
- 输出：实验设计

### Phase 2: 实验执行
- A/B测试自动部署和监控
- 输出：实验数据

### Phase 3: 结果分析
- 统计显著性检验 + 效果评估
- 输出：分析报告

### Phase 4: 规模化
- 验证通过的方案全量推广
- 输出：推广计划
