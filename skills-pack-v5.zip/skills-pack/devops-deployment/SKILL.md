---
name: devops-deployment
description: |
  部署运维技能——自动化部署和运维监控。
  触发词：CI/CD、部署、监控、容器、K8s、运维
version: 1.1.0
evolution_cycle: 7d
last_evolved: 2026-04-18
evolution_count: 1
score: 71/100
learning_sources:
  - type: industry_trend
    query: "DevOps 趋势 2026"
  - type: best_practice
    query: "CI/CD 最佳实践"
  - type: competitor
    query: "DevOps工具 竞品"
  - type: tech_update
    query: "容器 K8s 更新"
  - type: beginner_insight
    query: "DevOps 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增GitOps声明式持续交付、AI驱动运维异常检测与自愈、DevOps工具链治理、多环境灰度发布策略
  ]
---

# 部署运维

## 调用时机
- 需要部署应用
- 需要配置CI/CD
- 需要设置监控

## 工作流

### Phase 1: 环境准备
- 容器化、配置管理
- 输出：环境配置

### Phase 2: CI/CD流水线
- 自动化构建、测试、部署
- 输出：流水线配置

### Phase 3: 监控配置
- 日志、指标、告警规则
- 输出：监控配置

### Phase 4: 灾备方案
- 回滚策略、故障转移
- 输出：灾备方案
