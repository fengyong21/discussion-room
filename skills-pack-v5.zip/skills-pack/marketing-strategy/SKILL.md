---
name: marketing-strategy
description: |
  营销策略技能——制定营销计划和品牌策略。
  触发词：营销计划、品牌策略、GTM、市场推广
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 71/100
learning_sources:
  - type: industry_trend
    query: "数字营销 趋势 2026"
  - type: best_practice
    query: "营销策略 最佳实践"
  - type: competitor
    query: "营销平台 政策变化"
  - type: tech_update
    query: "营销AI工具"
  - type: beginner_insight
    query: "营销策划 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI精准获客策略、GEO（生成式引擎优化）营销、AI内容规模化生产与分发
  ]
---

# 营销策略

## 调用时机
- 需要制定营销计划
- 需要做品牌定位
- 需要规划GTM策略

## 工作流

### Phase 1: 市场定位
- 目标受众、价值主张、差异化定位
- 输出：定位文档

### Phase 2: 策略制定
- 营销组合（4P/4C）、渠道策略
- 输出：策略文档

### Phase 3: 预算分配
- 基于历史ROI的预算优化
- 输出：预算计划

### Phase 4: KPI设定
- 转化率、获客成本、LTV等指标
- 输出：KPI清单
