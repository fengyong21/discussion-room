---
name: data-collection
description: |
  数据采集技能——从多源采集和清洗数据。
  触发词：爬虫、ETL、数据管道、数据接入、数据采集
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "数据采集 隐私法规 2026"
  - type: best_practice
    query: "ETL 最佳实践"
  - type: competitor
    query: "数据采集工具"
  - type: tech_update
    query: "爬虫技术 反爬"
  - type: beginner_insight
    query: "数据采集 新手"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增智能体网络数据采集能力、多模态数据采集流程、合规审查自动化检查机制
  ]
---

# 数据采集

## 调用时机
- 需要采集外部数据
- 需要做ETL数据处理
- 需要搭建数据管道

## 工作流

### Phase 1: 数据源识别
- 内部数据库、外部API、网页、文件
- 输出：数据源清单

### Phase 2: 采集策略
- 全量/增量、频率、格式
- 输出：采集计划

### Phase 3: 数据清洗
- 去重、补全、标准化
- 输出：清洗后数据

### Phase 4: 数据入库
- 写入数据仓库/数据湖
- 输出：入库确认
