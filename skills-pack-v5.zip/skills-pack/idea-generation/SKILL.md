---
name: idea-generation
description: |
  创意生成技能——进行头脑风暴和方案创新。
  触发词：头脑风暴、创意、创新方案、概念验证
version: 1.1.0
evolution_cycle: 30d
last_evolved: 2026-04-18
evolution_count: 1
score: 68/100
learning_sources:
  - type: industry_trend
    query: "创新方法 趋势 2026"
  - type: best_practice
    query: "头脑风暴 方法论"
  - type: competitor
    query: "创意工具 AI"
  - type: tech_update
    query: "创新框架 TRIZ"
  - type: beginner_insight
    query: "创意思维 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI辅助创意生成工作流、跨领域创新组合方法、创意可行性快速验证框架
  ]
---

# 创意生成

## 调用时机
- 需要创意方案
- 需要头脑风暴
- 需要创新思路

## 工作流

### Phase 1: 约束定义
- 明确创新边界和目标
- 输出：创新约束清单

### Phase 2: 发散思维
- 生成大量创意方案（SCAMPER/TRIZ）
- 输出：创意池

### Phase 3: 收敛筛选
- 基于可行性、影响力、新颖度筛选
- 输出：Top 3方案

### Phase 4: 概念验证
- 为Top 3方案生成PoC计划
- 输出：PoC计划
