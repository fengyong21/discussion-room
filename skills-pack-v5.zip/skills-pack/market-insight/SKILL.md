---
name: market-insight
description: |
  市场洞察技能——识别市场信号和用户需求变化。
  触发词：市场调研、用户需求、行业动态、趋势分析
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "市场洞察 消费趋势 2026"
  - type: best_practice
    query: "市场调研 方法论"
  - type: competitor
    query: "市场调研工具 竞品"
  - type: tech_update
    query: "数据分析工具 市场研究"
  - type: beginner_insight
    query: "市场调研 新手怎么做"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增情绪消费/体验消费/绿色消费三维分析框架、下沉市场专项洞察模块、OMO渠道分析能力、纵向时间序列对比方法论
  ]
---

# 市场洞察

## 调用时机
- 需要了解市场动态
- 需要分析用户需求变化
- 需要识别市场机会

## 工作流

### Phase 1: 数据采集
- 爬取行业报告、新闻、社交媒体、竞品动态
- 输出：原始数据集

### Phase 2: 信号提取
- 从噪声中识别关键市场信号
- 输出：关键信号清单

### Phase 3: 用户画像更新
- 基于最新数据更新目标用户画像
- 输出：用户画像文档

### Phase 4: 洞察输出
- 生成结构化市场洞察报告
- 输出：洞察报告
