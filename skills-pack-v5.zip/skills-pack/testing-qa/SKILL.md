---
name: testing-qa
description: |
  测试QA技能——设计和执行测试用例。
  触发词：测试、QA、自动化测试、性能测试、回归测试
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "软件测试 趋势 2026"
  - type: best_practice
    query: "测试自动化 最佳实践"
  - type: competitor
    query: "测试工具 竞品"
  - type: tech_update
    query: "测试框架 更新"
  - type: beginner_insight
    query: "软件测试 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI原生质量保障体系、AI生成代码专项测试策略、AI测试用例自动生成、云原生分布式测试
  ]
---

# 测试QA

## 调用时机
- 需要编写测试用例
- 需要执行自动化测试
- 需要做性能测试

## 工作流

### Phase 1: 测试计划
- 根据需求生成测试用例
- 输出：测试用例文档

### Phase 2: 单元测试
- 自动生成并执行单元测试
- 输出：单元测试结果

### Phase 3: 集成测试
- API测试、端到端测试
- 输出：集成测试结果

### Phase 4: 测试报告
- 覆盖率、通过率、缺陷清单
- 输出：测试报告
