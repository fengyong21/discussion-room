---
name: channel-operations
description: |
  渠道运营技能——管理多渠道内容分发。
  触发词：社交媒体、广告投放、邮件营销、私域运营
version: 1.1.0
evolution_cycle: 7d
last_evolved: 2026-04-18
evolution_count: 1
score: 70/100
learning_sources:
  - type: industry_trend
    query: "社交媒体 算法 2026"
  - type: best_practice
    query: "渠道运营 最佳实践"
  - type: competitor
    query: "社交平台 功能更新"
  - type: tech_update
    query: "广告投放 工具"
  - type: beginner_insight
    query: "社交媒体运营 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增AI驱动渠道选择与GEO优化、短视频+搜索引擎协同获客策略
  ]
---

# 渠道运营

## 调用时机
- 需要在社交媒体发布内容
- 需要管理广告投放
- 需要做私域运营

## 工作流

### Phase 1: 渠道选择
- 基于受众匹配的渠道推荐
- 输出：渠道清单

### Phase 2: 内容分发
- 多渠道适配和定时发布
- 输出：发布计划

### Phase 3: 互动管理
- 评论回复、社区运营
- 输出：互动记录

### Phase 4: 效果追踪
- 各渠道ROI实时监控
- 输出：效果报告
