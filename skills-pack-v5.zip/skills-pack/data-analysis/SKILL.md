---
name: data-analysis
description: |
  数据分析技能——从数据中提取洞察，支持业务决策。
  触发词：数据分析、报表、BI、统计、数据可视化、数据洞察
version: 1.1.0
evolution_cycle: 14d
last_evolved: 2026-04-18
evolution_count: 1
score: 72/100
learning_sources:
  - type: industry_trend
    query: "数据分析 趋势 2026"
  - type: best_practice
    query: "数据分析 方法论"
  - type: competitor
    query: "BI工具 竞品"
  - type: tech_update
    query: "可视化库 更新"
  - type: beginner_insight
    query: "数据分析 入门"
evolution_log: [
  - date: 2026-04-18
    version: 1.1.0
    changes: 新增自然语言查询转分析逻辑能力、自动异常检测与归因分析、分析-决策-执行闭环能力
  ]
---

# 数据分析

## 调用时机
- 需要分析数据
- 需要生成报表或可视化
- 需要从数据中提取业务洞察

## 工作流

### Phase 1: 需求确认
- 明确分析目标和关键指标
- 确认数据来源和时间范围
- 确认输出格式（报告/图表/仪表盘）

### Phase 2: 数据探索
- 描述性统计（均值、中位数、分布）
- 数据质量检查（缺失值、异常值）
- 输出：数据概况摘要

### Phase 3: 深度分析
- 趋势分析、对比分析、归因分析
- 相关性分析、漏斗分析
- 输出：分析结论 + 可视化图表

### Phase 4: 洞察输出
- 生成结构化分析报告
- 包含：执行摘要、详细分析、可视化、行动建议
